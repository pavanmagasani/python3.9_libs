__title__ = 'include'
__summary__ = 'Dynamic import from files and other sources'
__url__ = 'https://github.com/maxfischer2781/include'

__version__ = '0.2.2'
__author__ = 'Max Fischer'
__email__ = 'maxfischer2781@gmail.com'
__copyright__ = '2017-2018 %s' % __author__
